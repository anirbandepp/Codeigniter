<?php  

class User_mod extends CI_Model
{
	
	public function dataIns($data)
	{
		$this->db->insert("record",$data);
	}
}

?>