<?php  

class Admin_mod extends CI_Model
{
	
	public function selRecord() {
		$q = $this->db->get("record");
		$rs = $q->result();
		return $rs;
	}

	public function sellAllRecord() {
		$q = $this->db->get("record");
		$res = $q->result();
		return count($res);
	}

	public function fetchData($id) {
		$this->db->where("id",$id);
		$q = $this->db->get("record");
		$rs = $q->result();
		return $rs;
	}

	public function updData($data,$id) {
		$this->db->where("id",$id);
		$this->db->update("record",$data);
	}

	public function delData($id) {
		$this->db->where("id",$id);
		$this->db->delete("record");
	}
}

?>