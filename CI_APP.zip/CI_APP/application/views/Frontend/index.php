<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>frontend/style.css">
</head>
<body>

	
	<section class="insfrm">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6">

					<div class="alert alert-success respdiv" id="resp">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
					  	<p id="output"></p>
					</div>

					<h1>Add Record</h1>
					<form id="insertData" method="POST">
						<div class="form-group">
							<label>Name of the country</label>
							<input type="text" name="country" id="country" class="form-control">
						</div>
						<div class="form-group">
							<label>ISO2 CODE</label>
							<input type="text" name="ISO2CODE" id="ISO2CODE" class="form-control">
						</div>
						<div class="form-group">
							<label>Calling Code</label>
							<input type="text" name="callingcode" id="callingcode" class="form-control">
						</div>
						<div class="form-group">
							<label>Capital City</label>
							<input type="text" name="capitalcity" id="capitalcity" class="form-control">
						</div>
						<div class="form-group">
							<label>Latitude</label>
							<input type="text" name="latitude" id="latitude" class="form-control">
						</div>
						<div class="form-group">
							<label>Longtiude</label>
							<input type="text" name="longtiude" id="longtiude" class="form-control">
						</div>
						<div class="form-group">
							<label>Your Name</label>
							<input type="text" name="name" id="name" class="form-control">
						</div>
						<input type="submit" id="submit" value="Submit" class="btn btn-primary">
					</form>
				</div>
			</div>
		</div>
	</section>


	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	  <script>
	  	$(document).ready(function(){

	  		$("body").on('submit', '#insertData', function(e) {
	  			e.preventDefault();
	  			
	  			var country = $("#country").val()
	  			var ISO2CODE = $("#ISO2CODE").val()
	  			var callingcode = $("#callingcode").val()
	  			var capitalcity = $("#capitalcity").val()
	  			var latitude = $("#latitude").val()
	  			var longtiude = $("#longtiude").val()
	  			var name = $("#name").val()

	  			if(country==""||ISO2CODE==""||callingcode==""||capitalcity==""||latitude==""||longtiude==""||name==""){
	  				$("#resp").show();
		  			$("#output").html("All fields are required");
	  			}else{
	  				$.ajax({
		  				url : '<?php echo base_url();?>dataIns',
		  				type : 'POST',
		  				data : $(this).serialize(),
		  				dataType : 'json',
		  				success : function(resp){
		  					$("#resp").show();
		  					$("#output").html(resp['msg']);
		  				}
		  			});
	  			}	  			
	  		});
	  	});
	  </script>

</body>
</html>
