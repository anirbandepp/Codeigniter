<?php  
	foreach ($row as $r) {
?>
<form id="updateData" method="POST">
	<input type="hidden" name="id" id="uid" value="<?php echo $r->id; ?>">
	<div class="form-group">
		<label>ISO2 CODE</label>
		<input type="text" name="ISO2CODE" id="ISO2CODE" value="<?php echo $r->ISO2CODE; ?>" 
		class="form-control">
	</div>
	<div class="form-group">
		<label>Calling Code</label>
		<input type="text" name="callingcode" id="callingcode" value="<?php echo $r->callingCode; ?>" 
		class="form-control">
	</div>
	<div class="form-group">
		<label>Capital City</label>
		<input type="text" name="capitalcity" id="capitalcity" value="<?php echo $r->capitalCity; ?>" 
		class="form-control">
	</div>
	<div class="form-group">
		<label>Latitude</label>
		<input type="text" name="latitude" id="latitude" value="<?php echo $r->LATITUDE; ?>" 
		class="form-control">
	</div>
	<div class="form-group">
		<label>Longtiude</label>
		<input type="text" name="longtiude" id="longtiude" value="<?php echo $r->LONGTIUDE; ?>" 
		class="form-control">
	</div>
	<input type="submit"  value="Update" class="btn btn-primary">
</form>
<?php 
	}	 
?>

