<header>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		<!-- Brand -->
		<a class="navbar-brand" href="<?php echo base_url() ?>cpnale/dashboard"> 
			Welcome
			<?php  
				$name = $this->session->userdata("admin_name");
				echo $name;
			?>
		</a>

		<!-- Toggler/collapsibe Button -->
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			<span class="navbar-toggler-icon"></span>
		</button>

		<!-- Navbar links -->
		<div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav ml-auto">
				   <li class="nav-item">
					    <a href="<?php echo base_url()?>cpnale/logout" class="btn btn-danger ">
					    	Logout
					    </a>
				   </li>
			</ul>
		</div>
	</nav>
</header>