<?php  
	foreach ($row as $r) {
?>
	<tr>
		<td> <?php echo $r->id ?> </td>
		<td> <?php echo $r->country ?> </td>
		<td> <?php echo $r->ISO2CODE ?> </td>
		<td> <?php echo $r->callingCode ?> </td>
		<td> <?php echo $r->capitalCity ?> </td>
		<td> <?php echo $r->LATITUDE ?> </td>
		<td> <?php echo $r->LONGTIUDE ?> </td>
		<td> <?php echo $r->name ?> </td>
		<td>
			<button class="btn btn-primary editBtn" data-eid="<?php echo $r->id ?>">Edit</button>
		</td>
		<td>
			<button class="btn btn-danger delBtn" data-did="<?php echo $r->id ?>">Delete</button>
		</td>
	</tr>
<?php  
	}
?>

