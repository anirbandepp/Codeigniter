<?php 
	$this->load->view('./Admin/inc/header.php'); 
	$this->load->view('./Admin/inc/nav.php'); 
?>

	<section class="insfrm">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-5">
					<div class="alert alert-success respdiv" id="resp">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
					  	<p id="output"></p>
					</div>
				</div>
			</div>

			<table class="table">
			    <thead>
			      <tr>
			      	<th>Sr No.</th>
			        <th>Country</th>
			        <th>ISO2CODE</th>
			        <th>Calling Code</th>
			        <th>Capital City</th>
			        <th>LATITUDE</th>
			        <th>LONGTIUDE</th>
			        <th>Name</th>
			        <th>Edit</th>
			        <th>Delete</th>
			      </tr>
			    </thead>
			    <tbody id="loadData">
			    </tbody>
		  </table>
		</div>
	</section>

<?php $this->load->view('./Admin/inc/footer.php'); ?>

<!-- The Modal -->
<div class="modal" id="editModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="editBody">
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<script>

	// Load data
	function loadData() {
		$.ajax({
			url: '<?php echo base_url(); ?>cpnale/selData',
			type: 'POST',
			data: 'string',
			success: function(response) {
				$("#loadData").html(response);
			}
		});
	} 
	loadData();

	// Send data into Modal
	$(document).on('click', '.editBtn', function() {
		var eid = $(this).data("eid");

		$.ajax({
			url : '<?php echo base_url();?>cpnale/edit',
			type : 'POST',
			data : { id : eid },
			success : function(resp){
				$("#editBody").html(resp);
				$("#editModal").modal("show");
			}
		});
	});

	// Update Modal Data
	$(document).on('submit', '#updateData', function(e) {
		e.preventDefault();
		
		$.ajax({
			url: '<?php echo base_url() ?>cpnale/updData',
			type: 'POST',
			data: $(this).serialize(),
			dataType : 'json',
			success: function(response) {
				$("#output").html(response['msg']);
				$(".respdiv").css('display', 'block').slideUp(3000);
				loadData();
				$("#editModal").modal("hide");
			}
		});
	});		

	// Delete Single Data
	$(document).on('click', '.delBtn', function(e) {
		if(confirm("Are you sure want to delete it ?")) {
			var eid = $(this).data("did");
			var element = this;
			
			$.ajax({
				url: '<?php echo base_url() ?>cpnale/delData',
				type: 'POST',
				data : { id : eid },
				dataType : 'json',
				success: function(response) {
					console.log(response);
					$(element).closest("tr").fadeOut();
					$("#output").html(response['msg']);
					$(".respdiv").css('display', 'block').slideUp(2000);
					loadData();
				}
			});
		}
	});		

</script>