<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>frontend/style.css">
</head>
<body>

	
	<section class="insfrm">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6">

					<div class="alert alert-success respdiv" id="resp">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
					  	<p id="output"></p>
					</div>

					<h1>Admim Login</h1>
					<form action="<?php echo base_url(); ?>cpnale/logincheck" method="POST">
						<div class="form-group">
							<label>Email ID</label>
							<input type="text" name="email" id="email" class="form-control">
						</div>
						<div class="form-group">
							<label>password</label>
							<input type="text" name="pass" id="pass" class="form-control">
						</div>
						<input type="submit" id="submit" value="Submit" class="btn btn-primary">
					</form>
					<p class="error_msg">
						<?php  
							if($this->session->set_flashdata('msg')!=""){
								echo $this->session->flashdata('msg');
							}
						?>
					</p>
				</div>
			</div>
		</div>
	</section>


	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	  <script>
	  	
	  </script>

</body>
</html>
