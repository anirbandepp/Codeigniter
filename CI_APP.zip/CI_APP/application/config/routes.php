<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'User/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Frontend View
$route['index'] = 'User/index';

// Send Data in Controller
$route['dataIns'] = 'User/dataIns';


// Admin Login
$route['cpnale/login'] = 'Login/alogin';

// Admin Login Check
$route['cpnale/logincheck'] = 'Login/logincheck';

// Admin Logout
$route['cpnale/logout'] = 'Admin/logout';

// Admin Area
$route['cpnale/dashboard'] = 'Admin/index';

// Select Record 
$route['cpnale/selData'] = 'Admin/selData';

// Edit Modal 
$route['cpnale/edit'] = 'Admin/editModal';

// Update Modal Data
$route['cpnale/updData'] = 'Admin/updData';

// Delete Modal Data
$route['cpnale/delData'] = 'Admin/delData';