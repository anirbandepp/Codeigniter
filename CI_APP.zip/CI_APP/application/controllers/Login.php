<?php  

class Login extends CI_Controller
{
	public function __construct() {
		parent::__construct();
		$this->load->helper("url");
		$this->load->database();
		$this->load->model("Login_mod");
		$this->load->library("session");
	}
	
	public function alogin() {
		$this->load->view("./Admin/login_admin.php");
	}

	public function logincheck() {
		$e = $this->input->post("email");
		$p = $this->input->post("pass");

		$rs = $this->Login_mod->lc($e,$p);
		if(count($rs)>0){
			foreach ($rs as $r) {
				$this->session->set_userdata("admin_id",$r->id);
				$this->session->set_userdata("admin_name",$r->name);
				redirect(base_url().'cpnale/dashboard');
			}
		}else{
			$this->session->set_flashdata('msg', 'Invalid Login');
			redirect(base_url().'login');
		}
	}
}

?>