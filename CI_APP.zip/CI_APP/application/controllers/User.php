<?php  


class User extends CI_Controller
{
	public function __construct() {
		parent::__construct();
		$this->load->helper("url");
		$this->load->database();
		$this->load->model("User_mod");
	}
	
	public function index(){
		$this->load->view("./Frontend/index.php");
	}

	public function dataIns(){

		echo $country = $this->input->post("country");
		$ISO2CODE = $this->input->post("ISO2CODE");
		$callingcode = $this->input->post("callingcode");
		$capitalcity = $this->input->post("capitalcity");
		$latitude = $this->input->post("latitude");
		$longtiude = $this->input->post("longtiude");
		$name = $this->input->post("name");

		$data = array(
			'country' => $country,
			'ISO2CODE' => $ISO2CODE,
			'callingcode' => $callingcode,
			'capitalcity' => $capitalcity,
			'latitude' => $latitude,
			'longtiude' => $longtiude,
			'name' => $name,
		);

		$this->User_mod->dataIns($data);

		$w = array(
				'status' => "200",
				'msg' => "Working",
			);
		
		echo json_encode($w);
	}
}

?>