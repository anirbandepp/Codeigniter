<?php  


class Admin extends CI_Controller
{
	public function __construct() {
		parent::__construct();
		$this->load->helper("url");
		$this->load->database();
		$this->load->model("Admin_mod");
		$this->load->library("session");
		$this->load->library("pagination");

		$admin_id = $this->session->userdata("admin_id");
		if($admin_id==""){
			redirect(base_url().'cpnale/login');
		}
	}
	
	// Admin Dashboard
	public function index(){
		$this->load->view("./Admin/admin.php");
	}

	// Admin Logout
	public function logout() {
		$this->session->unset_userdata("admin_id");
		$this->session->unset_userdata("admin_name");
		redirect(base_url().'cpnale/login');
	}

	//Show data dashboard
	public function selData() {

		$res = $this->Admin_mod->selRecord();

		$w = array(
			'row' => $res
		);

		$this->load->view('./Admin/list.php',$w);
	}

	// Fetch Single Dara for Edit Modal
	public function editModal() {

		$id = $this->input->post("id");

		$res = $this->Admin_mod->fetchData($id);

		$w = array(
			'row' => $res
		);

		$this->load->view('./Admin/modal/edit.php',$w);
	}

	// Update modal Data
	public function updData() {

		$id = $this->input->post("id");
		$ISO2CODE = $this->input->post("ISO2CODE");
		$callingcode = $this->input->post("callingcode");
		$capitalcity = $this->input->post("capitalcity");
		$latitude = $this->input->post("latitude");
		$longtiude = $this->input->post("longtiude");
		
		$w = array(
			'ISO2CODE' => $ISO2CODE,
			'callingCode' => $callingcode,
			'capitalCity' => $capitalcity,
			'LATITUDE' => $latitude,
			'LONGTIUDE' => $longtiude,
		);

		$this->Admin_mod->updData($w,$id);

		echo json_encode(
			array(
				'status' => 200,
				'msg' => 'file updated successfully'
			)
		);
	}

	// Delete single data
	public function delData() {
		 $id = $this->input->post("id");

		 $this->Admin_mod->delData($id);

		echo json_encode(
			array(
				'status' => 200,
				'msg' => 'file deleted successfully'
			)
		);
	}
}

?>